export let releases = [
    ['МНЕ ЛЕНЬ (TML Remix)', 'Arti Sun, klorbot, TMLYATL', "/releases/imLazyAlbum.png", "/releases/imLazy.mp3", false],
    ['плачь для меня', 'отложу на завтра', "/releases/cryForMeAlbum.jpg", "/releases/cryForMe.mp3", false],
    ['-Rep', 'klorbot', "/releases/minusRepAlbum.jpg", "/releases/minusRep.mp3", false],
    ['Танцпол', 'Arti Sun', "/releases/dancefloorAlbum.jpeg", "/releases/dancefloor.mp3", false],
]