import ArtiSun from "$lib/assets/artist_avaatars/ArtiSun.png"
import klorbot from "$lib/assets/artist_avaatars/klorbot.png"
import OSKENIS from "$lib/assets/artist_avaatars/OSKENIS.jpg"
import WALKER from "$lib/assets/artist_avaatars/WALKER.jpg"
import onTomorrow from "$lib/assets/artist_avaatars/onTomorrow.jpg"
import lazyLion from "$lib/assets/artist_avaatars/LazyLion.jpg"

export let artists = [
    ['Arti Sun', ArtiSun],
    ['OSKENIS', OSKENIS],
    ['ВАЛКЕР', WALKER],
    ['klorbot', klorbot],
    ["Lazy Lion", lazyLion],
    ['отложу на завтра', onTomorrow],
];